import firebase from "firebase/compat/app";
import "firebase/compat/database";

const firebaseConfig = {
    apiKey: "AIzaSyBHZvB0GFnLan0lr6fgC9VmJaCcqcJgYy8",
    authDomain: "crud-operation-2908.firebaseapp.com",
    projectId: "crud-operation-2908",
    storageBucket: "crud-operation-2908.appspot.com",
    messagingSenderId: "1006759827786",
    appId: "1:1006759827786:web:bd572a3e56891a1aa689b3"
  };

  const fireDb=firebase.initializeApp(firebaseConfig);
  export default fireDb.database().ref();